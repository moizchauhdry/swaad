

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Students</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-dark">
                            Back
                        </a>
                    </li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">
                            Student Detail
                        </h3>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <table class="table table-bordered">
                            <tbody>
                                <tr>
                                    <th><?php echo e(__('First Name')); ?></th>
                                    <td><?php echo e($student->fname); ?></td>
                                </tr>
                                <tr>
                                    <th><?php echo e(__('Last Name')); ?></th>
                                    <td><?php echo e($student->lname); ?></td>
                                </tr>
                                <tr>
                                    <th><?php echo e(__('Email')); ?></th>
                                    <td><?php echo e($student->email); ?></td>
                                </tr>
                                <tr>
                                    <th><?php echo e(__('Phone')); ?></th>
                                    <td><?php echo e($student->phone); ?></td>
                                </tr>
                                <tr>
                                    <th><?php echo e(__('Date of Birth')); ?></th>
                                    <td><?php echo e($student->dob); ?></td>
                                </tr>
                                <tr>
                                    <th><?php echo e(__('First Language')); ?></th>
                                    <td><?php echo e($student->language); ?></td>
                                </tr>
                                <tr>
                                    <th><?php echo e(__('Gender')); ?></th>
                                    <td><?php echo e($student->gender); ?></td>
                                </tr>
                                <tr>
                                    <th><?php echo e(__('Marital Status')); ?></th>
                                    <td><?php echo e($student->marital_status); ?></td>
                                </tr>
                                <tr>
                                    <th><?php echo e(__('Nationality')); ?></th>
                                    <td><?php echo e($student->nationality); ?></td>
                                </tr>
                                <tr>
                                    <th><?php echo e(__('Country of Citizenship')); ?></th>
                                    <td><?php echo e($student->citizenship); ?></td>
                                </tr>
                                <tr>
                                    <th><?php echo e(__('Country')); ?></th>
                                    <td> <?php echo e(isset($student->country) ? $student->country->name : '- -'); ?></td>
                                </tr>
                                <tr>
                                    <th><?php echo e(__('City')); ?></th>
                                    <td> <?php echo e(isset($student->city) ? $student->city->name : '- -'); ?></td>
                                </tr>
                                <tr>
                                    <th><?php echo e(__('State / Province')); ?></th>
                                    <td> <?php echo e(isset($student->state) ? $student->state->name : '- -'); ?></td>
                                </tr>
                                <tr>
                                    <th><?php echo e(__('Postal / Zip code')); ?></th>
                                    <td><?php echo e($student->zipcode); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\breeo_canada\resources\views/admin/students/detail.blade.php ENDPATH**/ ?>