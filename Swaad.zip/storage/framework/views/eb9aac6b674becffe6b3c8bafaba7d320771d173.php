<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="javascript:void(0)" class="brand-link">
        <img src="<?php echo e(asset('public/admin/dist/img/AdminLTELogo.png')); ?>" class="brand-image img-circle elevation-3"
            style="opacity: .8">
        <span class="brand-text font-weight-light">Breoo Canada</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="<?php echo e(asset('public/admin/dist/img/user2-160x160.jpg')); ?>" class="img-circle elevation-2">
            </div>
            <div class="info">
                <a href="javascript:void(0)" class="d-block"><?php echo e(Auth::guard('admin')->user()->name); ?></a>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">

                <li class="nav-item">
                    <a href="<?php echo e(route('admin.dashboard')); ?>"
                        class="nav-link <?php echo e((Route::currentRouteName() == 'admin.dashboard') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>
                            Dashboard
                        </p>
                    </a>
                </li>

                <?php if(Auth::guard('admin')->user()->hasPermission('manage-admin-users')): ?>
                <li
                    class="nav-item has-treeview <?php echo e((Route::currentRouteName() == 'admins.create' || Route::currentRouteName() == 'admins.index'|| Route::currentRouteName() == 'admins.edit' ) ? 'menu-open' : ''); ?>">
                    <a href="#"
                        class="nav-link <?php echo e((Route::currentRouteName() == 'admins.create' || Route::currentRouteName() == 'admins.index' || Route::currentRouteName() == 'admins.edit' ) ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-user-cog"></i>
                        <p>
                            Admin Users
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admins.create')); ?>"
                                class="nav-link <?php echo e((Route::currentRouteName() == 'admins.create') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Add Admin User</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admins.index')); ?>"
                                class="nav-link <?php echo e((Route::currentRouteName() == 'admins.index' || Route::currentRouteName() == 'admins.edit' ) ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>List Admin Users</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if(Auth::guard('admin')->user()->hasPermission('manage-banners')): ?>
                <li class="nav-item has-treeview <?php echo e((Route::currentRouteName() == 'banners.create' || Route::currentRouteName() == 'banners.index' || Route::currentRouteName() == 'banners.edit' ) ? 'menu-open' : ''); ?>

                ">
                    <a href="#" class="nav-link <?php echo e((Route::currentRouteName() == 'banners.create' || Route::currentRouteName() == 'banners.index' || Route::currentRouteName() == 'banners.edit' ) ? 'active' : ''); ?>

                    ">
                        <i class="nav-icon far fa-images"></i>
                        <p>
                            Banners
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('banners.create')); ?>"
                                class="nav-link <?php echo e((Route::currentRouteName() == 'banners.create') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Add Banner</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('banners.index')); ?>"
                                class="nav-link <?php echo e((Route::currentRouteName() == 'banners.index' || Route::currentRouteName() == 'banners.edit' ) ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>List Banners</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if(Auth::guard('admin')->user()->hasPermission('manage-countries')): ?>
                <li class="nav-item has-treeview <?php echo e((Route::currentRouteName() == 'countries.create' || Route::currentRouteName() == 'countries.index' || Route::currentRouteName() == 'countries.edit' ) ? 'menu-open' : ''); ?>

                ">
                    <a href="#" class="nav-link <?php echo e((Route::currentRouteName() == 'countries.create' || Route::currentRouteName() == 'countries.index' || Route::currentRouteName() == 'countries.edit' ) ? 'active' : ''); ?>

                    ">
                        <i class="nav-icon fas fa-globe-americas"></i>
                        <p>
                            Countries
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('countries.create')); ?>"
                                class="nav-link <?php echo e((Route::currentRouteName() == 'countries.create') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Add Country</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('countries.index')); ?>"
                                class="nav-link <?php echo e((Route::currentRouteName() == 'countries.index' || Route::currentRouteName() == 'countries.edit' ) ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>List Countries</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if(Auth::guard('admin')->user()->hasPermission('manage-states')): ?>
                <li class="nav-item has-treeview <?php echo e((Route::currentRouteName() == 'states.create' || Route::currentRouteName() == 'states.index' || Route::currentRouteName() == 'states.edit' ) ? 'menu-open' : ''); ?>

                ">
                    <a href="#" class="nav-link <?php echo e((Route::currentRouteName() == 'states.create' || Route::currentRouteName() == 'states.index' || Route::currentRouteName() == 'states.edit' ) ? 'active' : ''); ?>

                    ">
                        <i class="nav-icon far fa-flag"></i>
                        <p>
                            States
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('states.create')); ?>"
                                class="nav-link <?php echo e((Route::currentRouteName() == 'states.create') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Add State</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('states.index')); ?>"
                                class="nav-link <?php echo e((Route::currentRouteName() == 'states.index' || Route::currentRouteName() == 'states.edit' ) ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>List States</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if(Auth::guard('admin')->user()->hasPermission('manage-cities')): ?>
                <li class="nav-item has-treeview <?php echo e((Route::currentRouteName() == 'cities.create' || Route::currentRouteName() == 'cities.index' || Route::currentRouteName() == 'cities.edit' ) ? 'menu-open' : ''); ?>

                ">
                    <a href="#" class="nav-link <?php echo e((Route::currentRouteName() == 'cities.create' || Route::currentRouteName() == 'cities.index' || Route::currentRouteName() == 'cities.edit' ) ? 'active' : ''); ?>

                    ">
                        <i class="nav-icon far fa-building"></i>
                        <p>
                            Cities
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('cities.create')); ?>"
                                class="nav-link <?php echo e((Route::currentRouteName() == 'cities.create') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Add City</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('cities.index')); ?>"
                                class="nav-link <?php echo e((Route::currentRouteName() == 'cities.index' || Route::currentRouteName() == 'cities.edit' ) ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>List Cities</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if(Auth::guard('admin')->user()->hasPermission('manage-programs')): ?>
                <li class="nav-item has-treeview <?php echo e((Route::currentRouteName() == 'programs.create' || Route::currentRouteName() == 'programs.index' || Route::currentRouteName() == 'programs.edit' ) ? 'menu-open' : ''); ?>

                ">
                    <a href="#" class="nav-link <?php echo e((Route::currentRouteName() == 'programs.create' || Route::currentRouteName() == 'programs.index' || Route::currentRouteName() == 'programs.edit' ) ? 'active' : ''); ?>

                    ">
                        <i class="nav-icon fas fa-tasks"></i>
                        <p>
                            Programs
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('programs.create')); ?>"
                                class="nav-link <?php echo e((Route::currentRouteName() == 'programs.create') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Add Program</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('programs.index')); ?>"
                                class="nav-link <?php echo e((Route::currentRouteName() == 'programs.index' || Route::currentRouteName() == 'programs.edit' ) ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>List Programs</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if(Auth::guard('admin')->user()->hasPermission('manage-accreditations')): ?>
                <li class="nav-item has-treeview <?php echo e((Route::currentRouteName() == 'accreditations.create' || Route::currentRouteName() == 'accreditations.index' || Route::currentRouteName() == 'accreditations.edit' ) ? 'menu-open' : ''); ?>

                ">
                    <a href="#" class="nav-link <?php echo e((Route::currentRouteName() == 'accreditations.create' || Route::currentRouteName() == 'accreditations.index' || Route::currentRouteName() == 'accreditations.edit' ) ? 'active' : ''); ?>

                    ">
                        <i class="nav-icon fas fa-landmark"></i>
                        <p>
                            Accreditations
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('accreditations.create')); ?>"
                                class="nav-link <?php echo e((Route::currentRouteName() == 'accreditations.create') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Add Accreditation</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('accreditations.index')); ?>"
                                class="nav-link <?php echo e((Route::currentRouteName() == 'accreditations.index' || Route::currentRouteName() == 'accreditations.edit' ) ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>List Accreditations</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if(Auth::guard('admin')->user()->hasPermission('manage-services')): ?>
                <li class="nav-item has-treeview <?php echo e((Route::currentRouteName() == 'services.create' || Route::currentRouteName() == 'services.index' || Route::currentRouteName() == 'services.edit' ) ? 'menu-open' : ''); ?>

                ">
                    <a href="#" class="nav-link <?php echo e((Route::currentRouteName() == 'services.create' || Route::currentRouteName() == 'services.index' || Route::currentRouteName() == 'services.edit' ) ? 'active' : ''); ?>

                    ">
                        <i class="nav-icon fas fa-toolbox"></i>
                        <p>
                            Services
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('services.create')); ?>"
                                class="nav-link <?php echo e((Route::currentRouteName() == 'services.create') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Add Service</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('services.index')); ?>"
                                class="nav-link <?php echo e((Route::currentRouteName() == 'services.index' || Route::currentRouteName() == 'services.edit' ) ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>List Services</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if(Auth::guard('admin')->user()->hasPermission('manage-types')): ?>
                <li class="nav-item has-treeview <?php echo e((Route::currentRouteName() == 'types.create' || Route::currentRouteName() == 'types.index' || Route::currentRouteName() == 'types.edit' ) ? 'menu-open' : ''); ?>

                ">
                    <a href="#" class="nav-link <?php echo e((Route::currentRouteName() == 'types.create' || Route::currentRouteName() == 'types.index' || Route::currentRouteName() == 'types.edit' ) ? 'active' : ''); ?>

                    ">
                        <i class="nav-icon far fa-address-card"></i>
                        <p>
                            Types
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('types.create')); ?>"
                                class="nav-link <?php echo e((Route::currentRouteName() == 'types.create') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Add Type</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('types.index')); ?>"
                                class="nav-link <?php echo e((Route::currentRouteName() == 'types.index' || Route::currentRouteName() == 'types.edit' ) ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>List Types</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if(Auth::guard('admin')->user()->hasPermission('manage-clients')): ?>
                <li class="nav-item has-treeview <?php echo e((Route::currentRouteName() == 'students.create' || Route::currentRouteName() == 'students.index' || Route::currentRouteName() == 'students.edit' ) ? 'menu-open' : ''); ?>

                ">
                    <a href="#" class="nav-link <?php echo e((Route::currentRouteName() == 'students.create' || Route::currentRouteName() == 'students.index' || Route::currentRouteName() == 'students.edit' ) ? 'active' : ''); ?>

                    ">
                        <i class="nav-icon fas fa-user-graduate"></i>
                        <p>
                            Students
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('students.create')); ?>"
                                class="nav-link <?php echo e((Route::currentRouteName() == 'students.create') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Add Student</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('students.index')); ?>"
                                class="nav-link <?php echo e((Route::currentRouteName() == 'students.index' || Route::currentRouteName() == 'students.edit' ) ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>List Students</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if(Auth::guard('admin')->user()->hasPermission('manage-cases')): ?>
                <li class="nav-item has-treeview <?php echo e((Route::currentRouteName() == 'cases.create' || Route::currentRouteName() == 'cases.index' || Route::currentRouteName() == 'cases.edit' ) ? 'menu-open' : ''); ?>

                ">
                    <a href="#" class="nav-link <?php echo e((Route::currentRouteName() == 'cases.create' || Route::currentRouteName() == 'cases.index' || Route::currentRouteName() == 'cases.edit' ) ? 'active' : ''); ?>

                    ">
                        <i class="nav-icon fas fa-book-open"></i>
                        <p>
                            Cases
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('cases.create')); ?>"
                                class="nav-link <?php echo e((Route::currentRouteName() == 'cases.create') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Add Case</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('cases.index')); ?>"
                                class="nav-link <?php echo e((Route::currentRouteName() == 'cases.index' || Route::currentRouteName() == 'cases.edit' ) ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>List Cases</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if(Auth::guard('admin')->user()->hasPermission('manage-agents')): ?>
                <li class="nav-item has-treeview <?php echo e((Route::currentRouteName() == 'agents.create' || Route::currentRouteName() == 'agents.index' || Route::currentRouteName() == 'agents.edit' ) ? 'menu-open' : ''); ?>

                ">
                    <a href="#" class="nav-link <?php echo e((Route::currentRouteName() == 'agents.create' || Route::currentRouteName() == 'agents.index' || Route::currentRouteName() == 'agents.edit' ) ? 'active' : ''); ?>

                    ">
                        <i class="nav-icon fas fa-user-tie"></i>
                        <p>
                            Agents
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('agents.create')); ?>"
                                class="nav-link <?php echo e((Route::currentRouteName() == 'agents.create') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Add Agent</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('agents.index')); ?>"
                                class="nav-link <?php echo e((Route::currentRouteName() == 'agents.index' || Route::currentRouteName() == 'agents.edit' ) ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>List Agent</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside><?php /**PATH C:\xampp\htdocs\breeo_canada\resources\views/admin/includes/sidebar.blade.php ENDPATH**/ ?>