<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
        <h5>Title</h5>
        <a href="<?php echo e(route('admin.logout')); ?>" class="btn btn-outline-dark btn-border btn-sm">
            <i class="fas fa-sign-out-alt mr-2"></i>Logout</a>
    </div>
</aside>
<!-- /.control-sidebar -->

<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
        Anything you want
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2020 <a href="#">Breeo Canada</a>.</strong> All rights reserved.
</footer><?php /**PATH C:\xampp\htdocs\breeo_canada\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>