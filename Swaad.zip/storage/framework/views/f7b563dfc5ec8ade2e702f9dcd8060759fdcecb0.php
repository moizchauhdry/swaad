

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Banners</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('banners.create')); ?>" class="btn btn-success">
                            Add New Banner
                        </a>
                    </li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            Banners List (Total Banners : <?php echo e($banners->count()); ?>)
                        </h3>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <table id="banners" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Image</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($banner->id); ?></td>
                                    <td>
                                        <img class="w-25" src="<?php echo e(asset('storage/app/'.$banner->image_url)); ?>">
                                    </td>
                                    <td>
                                        <?php if($banner->status == 1): ?>
                                        <span class="badge badge-success">Active</span>
                                        <?php else: ?>
                                        <span class="badge badge-danger">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('banners.edit', $banner->id)); ?>" class="mr-2">
                                            <i class="fa fa-edit" aria-hidden="true"></i>
                                        </a>
                                        <a href="javascript:void(0);" onclick="deleteBanner('<?php echo e($banner->id); ?>');">
                                            <i class="fa fa-trash" aria-hidden="true"></i>
                                        </a>
                                    </td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(function () {
      $("#banners").DataTable({
        "responsive": true,
        "autoWidth": false,
      });
    });
    // Delete Banner
    function deleteBanner(banner_id) {
        var result = window.confirm('Are you sure you want to delete this Banner?  This action cannot be undone. Proceed?');
        if (result == false) {
            e.preventDefault();
        }else{

            $.ajax({
                method: "POST",
                url: './banner/delete',
                data: { 
                    _token: $('meta[name="csrf-token"]').attr('content'),
                    'banner_id': banner_id 
                    },
                success: function (response) {
                    location.reload();
                }
            });
        }
    };
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\breeo_canada\resources\views/admin/banners/index.blade.php ENDPATH**/ ?>