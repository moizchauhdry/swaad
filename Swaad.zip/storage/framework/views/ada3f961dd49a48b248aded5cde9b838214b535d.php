<!-- jQuery -->
<script src="<?php echo e(asset('public/admin/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('public/admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- overlayScrollbars -->
<script src="<?php echo e(asset('public/admin/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')); ?>">
</script>
<!-- Admin App-->
<script src="<?php echo e(asset('public/admin/dist/js/adminlte.min.js')); ?>"></script>

<!-- DataTables -->
<script src="<?php echo e(asset('public/admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/admin/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>">
</script>
<script src="<?php echo e(asset('public/admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>">
</script>

<!-- DataTables Export Buttons Download -->
<script src="https://cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.colVis.min.js"></script>

<!-- Select2 -->
<script src="<?php echo e(asset('public/admin/plugins/select2/js/select2.full.min.js')); ?>"></script>

<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>

<script>
    // Disable Error & Success Message After 2 Sec's
        function dismiss_alerts() {
                window.setTimeout(function () {
                    $(".alert").fadeTo(2500, 0).slideUp(500, function () {
                        $(this).remove();
                    });
                }, 2000);
            }
            $(document).ready(function () {
                dismiss_alerts();
            });
</script>

<?php echo $__env->yieldContent('extra-scripts'); ?><?php /**PATH C:\xampp\htdocs\breeo_canada\resources\views/admin/includes/scripts.blade.php ENDPATH**/ ?>