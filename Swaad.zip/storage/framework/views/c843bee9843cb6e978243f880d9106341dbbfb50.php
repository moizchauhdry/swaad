

<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Categories</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('categories.create')); ?>" class="btn btn-success btn-sm">
                            <i class="fas fa-plus mr-1" aria-hidden="true"></i> Add Category</a></li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            Categories List (Total Categories : <?php echo e($categories->count()); ?>)
                        </h3>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Sr #</th>
                                    <th>Title</th>
                                    <th>Image</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $count = 1; ?>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($count ++); ?></td>
                                    <td><?php echo e($category->title); ?></td>
                                    <td>
                                        <?php if($category->image_url != NULL && Storage::exists($category->image_url)): ?>
                                        <img src="<?php echo e(asset('storage/app/public/'.$category->image_url)); ?>" id="image"
                                            class="w-25" />
                                        <?php else: ?>
                                        <img src="<?php echo e(asset('public/images/placeholder.png')); ?>" id="image"
                                            class="w-25" />
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($category->status == 1): ?>
                                        <span class="badge badge-success">Active</span>
                                        <?php else: ?>
                                        <span class="badge badge-danger">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('categories.edit',$category->id)); ?>"
                                            class="btn btn-primary btn-sm">
                                            <i class="far fa-edit" aria-hidden="true"></i> Edit
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(function () {
      $("#example1").DataTable({
        "responsive": true,
        "autoWidth": false,
      });
    });

    // Deactivate/Delete Categories Level 1
    function deactivateCategory(category_id) {
        var result = window.confirm('Are you sure you want to Delete this Category?');
        if (result == false) {
            event.preventDefault();
        } else {
            $.ajax({
                method: "POST",
                url: './category/deactivate',
                data: { 
                    _token: $('meta[name="csrf-token"]').attr('content'),
                    'category_id': category_id
                    },
                success: function (response) {
                    alert('success')
                    location.reload();                
                }
            });
        }
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Swaad\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>