<section id="home-section" class="hero">
    <div class="home-slider owl-carousel">

        <div class="slider-item" style="background-image: url(<?php echo e(asset('public/frontend/images/bg_1.jpg')); ?>);">
            <div class="overlay"></div>
            <div class="container">
                <div class="row slider-text justify-content-center align-items-center" data-scrollax-parent="true">
                </div>
            </div>
        </div>

        <div class="slider-item" style="background-image: url(<?php echo e(asset('public/frontend/images/bg_2.jpg')); ?>);">
            <div class="overlay"></div>
            <div class="container">
                <div class="row slider-text justify-content-center align-items-center" data-scrollax-parent="true">
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\xampp\htdocs\Swaad\resources\views/frontend/includes/slider.blade.php ENDPATH**/ ?>